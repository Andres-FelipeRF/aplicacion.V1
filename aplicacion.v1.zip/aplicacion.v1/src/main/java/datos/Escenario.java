/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import java.sql.Time;
import java.util.Date;

/**
 *
 * @author mfnaa
 */
public class Escenario {
    public Date fechaReserva;
    public int horasReserva;
    public int precio;
    
    public long calcularCosto(){
        int precioTotal;
        
        precioTotal = precio*horasReserva;
        return precioTotal;
    }
}
