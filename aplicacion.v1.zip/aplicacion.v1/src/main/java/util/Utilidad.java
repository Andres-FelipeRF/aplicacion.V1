/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mfnaa
 */
public class Utilidad {
    public final String ARCHIVO = "datos.app";
    public void guardar(String linea){
        File f = new File(ARCHIVO);
        try {
            FileWriter fw = new FileWriter(f);
            fw.write(linea);
            fw.close();
        } catch (IOException ex) {
            Logger.getLogger(Utilidad.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public String consultar(){
        File f = new File(ARCHIVO);
        try {
            FileReader fw = new FileReader(f);
            BufferedReader buf = new BufferedReader(fw);
            String linea =  buf.readLine();
            buf.close();
            if (linea == null)
                return "";
            else
                return linea;
        } catch (IOException ex) {
            Logger.getLogger(Utilidad.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }
    public static void main(String[] args) {
        String usuario = "jose-perez-luis-reerr-yyy";
        Utilidad util = new Utilidad();
        util.guardar(usuario);
        
        String otro = util.consultar();
        System.out.println("leido "+otro);
        String[] partido = otro.split("-");
        System.out.println(partido[0]);
        System.out.println(partido[1]);
        System.out.println(partido[2]);
    }
}
