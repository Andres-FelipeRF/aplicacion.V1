/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interaccion;

/**
 *
 * @author mfnaa
 */
public class Caracteristicas {
    
    public String mostrarDetalles(){
        return "";
    }
    public String resumenReserva(){
        return "";
    }
}
