/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interaccion;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author mfnaa
 */
public class Reservas{
    public final String ARCHIVO_RESERVAS = "datos_reservas.app";
    public void guardarReserva(String linea){
        File f = new File(ARCHIVO_RESERVAS);
        try {
            FileWriter fw = new FileWriter(f);
            fw.write(linea);
            fw.close();
        } catch (IOException ex) {
            Logger.getLogger(Reservas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public String consultar(){
        File f = new File(ARCHIVO_RESERVAS);
        try {
            FileReader fw = new FileReader(f);
            BufferedReader buf = new BufferedReader(fw);
            String linea =  buf.readLine();
            buf.close();
            if (linea == null)
                return "";
            else
                return linea;
        } catch (IOException ex) {
            Logger.getLogger(Reservas.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";

    }
}
